import React from 'react';

function Footer() {

   
  return (
     <>
  <div className="page-footer">
            <p>2022 &copy; stacks</p>
        </div>
     </>
  );
}
export default Footer;